**To delete a Usage Plan**

Command::

  aws apigateway delete-usage-plan --usage-plan-id a1b2c3 --region us-west-2

