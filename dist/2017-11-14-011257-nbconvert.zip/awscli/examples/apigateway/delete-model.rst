**To delete a model in the given API within the specified region**

Command::

  aws apigateway delete-model --rest-api-id 1234123412 --model-name 'customModel' --region us-west-2

